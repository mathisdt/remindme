package de.jutzig.jnotification;
/**
 * 
 * @author jutzig<p>
 * Enumerates the possible positions for notifications 
 *
 */
public enum Corner {
	UPPER_LEFT,
	UPPER_RIGHT,
	LOWER_RIGHT,
	LOWER_LEFT
}
