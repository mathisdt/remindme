/**
 * de.jutzig.jnotification.PopupManager.java
 * created by Johannes Utzig at 05.05.2007
 * 
 * This Source Code is licensed under GPLv3 
 */
package de.jutzig.jnotification;

import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JWindow;
import javax.swing.Timer;

import de.jutzig.jnotification.event.NotificationEvent;
import de.jutzig.jnotification.event.NotificationEventType;
import de.jutzig.jnotification.event.NotificationListener;

/**
 * @author jutzig<p>
 * 
 * <p>
 * Responsible for managing the Popups.
 * <p>
 * Instead of making the Popups visible on your own, you should use the API of
 * this class to take care of the position, duration, disposing. <b> be aware
 * that manipulating a {@link JNotificationPopup} with the methods inherited
 * from {@link JWindow}, the state of the <code>PopupManager</code> might
 * become inconsistant.
 * <p>
 * Typically you'd use the PopupManager like that:<p>
 * <code>//instanciate a Manager instance that displays popups for 20 seconds in the lower right corner with no offset<b>
 *         PopupManager manager = new PopupManager(20000,Corner.LOWER_RIGHT,new Point(0,0));<b>
 *         //instanciate a new Popup and set it a Component to its ContentPane<b> 
 *		JNotificationPopup popup = new JNotificationPopup(new JLabel("A Notification!");<b>
 *  	//optionally, set it an Animator<b>
 *		popup.setAnimator(new FadeIn(popup,2000));<b>
 *		//enqueue the popup in the managers queue<b>
 *		manager.enqueuePopup(popup);</code><b>
 */
public class PopupManager {

	private LinkedList<JNotificationPopup> dialogs;

	private int durationTime;

	private Corner corner;

	private Point insertionPoint;

	private Point lastPosition;

	private Point offset;
	
	private LinkedList<WeakReference<NotificationListener>> listeners = new LinkedList<WeakReference<NotificationListener>>();

	/**
	 * creates a new PopupManager instance with the given settings.
	 * @param durationTime - the time a popup will be shown
	 * @param corner - one of {@link Corner#LOWER_LEFT}, {@link Corner#LOWER_RIGHT}, {@link Corner#LOWER_RIGHT}, {@link Corner#LOWER_LEFT}
	 * @param offset - specifies how far away of the specified {@link Corner} the first popup will be shown.
	 */
	public PopupManager(int durationTime, Corner corner, Point offset) {
		super();
		this.durationTime = durationTime;
		this.corner = corner;
		this.offset = offset;
		dialogs = new LinkedList<JNotificationPopup>();
	}
	
	/**
	 * delegates to {@link PopupManager#PopupManager(30000, Corner.LOWER_RIGHT, new Point(0,0)}
	 *
	 */
	public PopupManager() {
		this(30000, Corner.LOWER_RIGHT, new Point(0, 0));
	}
	
	/**
	 * enqueues the specified {@link JNotificationPopup} to the list.
	 * The Popup will be made visible and a {@link Timer} will be started.
	 * @param popup
	 * @return success
	 */
	public boolean enqueuePopup(JNotificationPopup popup) {
		if (durationTime > 0) {
			Timer timer = new Timer(durationTime, new TimerListner(popup));
			timer.setRepeats(false);
			timer.start();
		}
		calculateInsets(popup);
		Point destination = null;
		switch (corner) {
		case UPPER_LEFT:
			destination = lastPosition;
			popup.getAnimator().showPopupAt(new Point(lastPosition));
			lastPosition.y += popup.getHeight();
			break;
		case UPPER_RIGHT:
			destination = new Point(lastPosition.x - popup.getWidth(),lastPosition.y);
			popup.getAnimator().showPopupAt(new Point(destination));
			lastPosition.y += popup.getHeight();
			break;
		case LOWER_LEFT:
			lastPosition.y -= popup.getHeight();
			destination = new Point(lastPosition.x, lastPosition.y);
			popup.getAnimator().showPopupAt(new Point(destination));
					
			break;
		case LOWER_RIGHT:
			lastPosition.y -= popup.getHeight();
			destination = new Point(new Point(lastPosition.x - popup.getWidth(),lastPosition.y));
			popup.getAnimator().showPopupAt(new Point(destination));
			break;
		}
		fireNotificationEvent(new NotificationEvent(null,destination,popup,NotificationEventType.DISPLAYED));
		return dialogs.add(popup);
	}

	/**
	 * takes the Popup out of the list and disposes it
	 * @param popup
	 * @return success
	 */
	public boolean dequeuePopup(JNotificationPopup popup) {
		Point from = popup.getLocation();
		popup.getAnimator().hidePopup();
		boolean value = dialogs.remove(popup);
		if(!value)
			return false;
		fireNotificationEvent(new NotificationEvent(from,null,popup,NotificationEventType.HIDDEN));
		orderDialogs();
		return value;
	}

	private void orderDialogs() {
		Point location = new Point(insertionPoint);

		switch (corner) {
		case UPPER_LEFT:
			for (JNotificationPopup popup : dialogs) {
				Point from = popup.getLocation();
				Point to = new Point(location);
				popup.getAnimator().movePopup(new Point(location));
				location.y += popup.getHeight();
				fireNotificationEvent(new NotificationEvent(from,to,popup,NotificationEventType.MOVED));
			}
			break;
		case UPPER_RIGHT:
			for (JNotificationPopup popup : dialogs) {
				Point from = popup.getLocation();
				Point to = new Point(location.x - popup.getWidth(), location.y);
				popup.getAnimator().movePopup(new Point(to));
				location.y += popup.getHeight();
				fireNotificationEvent(new NotificationEvent(from,to,popup,NotificationEventType.MOVED));
			}
			break;
		case LOWER_RIGHT:
			for (JNotificationPopup popup : dialogs) {
				Point from = popup.getLocation();
				location.y -= popup.getHeight();
				Point to = new Point(location.x - popup.getWidth(), location.y);
				popup.getAnimator().movePopup(new Point(to));
				fireNotificationEvent(new NotificationEvent(from,to,popup,NotificationEventType.MOVED));
			}
			break;
		case LOWER_LEFT:
			for (JNotificationPopup popup : dialogs) {
				Point from = popup.getLocation();
				location.y -= popup.getHeight();
				Point to = new Point(location);
				popup.getAnimator().movePopup(new Point(location));
				fireNotificationEvent(new NotificationEvent(from,to,popup,NotificationEventType.MOVED));

			}
			break;
		}

		lastPosition = location;
	}

	private void calculateInsets(JNotificationPopup popup) {
		Point oldPoint = null;
		if (insertionPoint != null)
			oldPoint = new Point(insertionPoint);

		Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
		Insets insets = Toolkit.getDefaultToolkit().getScreenInsets(
				popup.getGraphicsConfiguration());

		switch (corner) {
		case UPPER_LEFT:
			insertionPoint = new Point(insets.left + offset.x, insets.top
					+ offset.y);

			break;
		case UPPER_RIGHT:
			insertionPoint = new Point(size.width - insets.right - offset.x,
					insets.top + offset.y);

			break;
		case LOWER_RIGHT:
			insertionPoint = new Point(size.width - insets.right - offset.x,
					size.height - insets.bottom - offset.y);

			break;
		case LOWER_LEFT:
			insertionPoint = new Point(insets.left + offset.x, size.height
					- insets.bottom - offset.y);
			break;
		}
		if (oldPoint != null && lastPosition != null) {
			lastPosition.x += insertionPoint.x - oldPoint.x;
			lastPosition.y += insertionPoint.y - oldPoint.y;
		} else if (lastPosition == null)
			lastPosition = new Point(insertionPoint);
	}
	/**
	 * 
	 * @author jutzig
	 * 
	 * little helper class that's called when a timer is expired
	 *
	 */
	class TimerListner implements ActionListener {

		private JNotificationPopup popup;
		
		/**
		 * creates a TimerListener instance
		 * @param popup
		 */
		public TimerListner(JNotificationPopup popup) {
			super();
			this.popup = popup;
		}
		
		/**
		 * @see ActionListener#actionPerformed(ActionEvent)
		 */
		public void actionPerformed(ActionEvent e) {
			dequeuePopup(popup);

		}
	}
	
	private void fireNotificationEvent(NotificationEvent event)
	{
		for (WeakReference<NotificationListener> ref : listeners) {
			ref.get().popupStateChanged(event);
		}
	}
	
	/**
	 * adds a listener to the list to get informed about popup-changes<p>
	 * The Listeners are kept as a {@link WeakReference}
	 * @param listener
	 */
	public void addNotifcationListener(NotificationListener listener){
		listeners.add(new WeakReference<NotificationListener>(listener));
	}
	
	/**
	 * removes the listener from the list
	 * @param listener
	 * @return
	 */
	public boolean removeNotifcationListener(NotificationListener listener){
		Iterator<WeakReference<NotificationListener>> it = listeners.iterator();
		while(it.hasNext()) {
			WeakReference<NotificationListener> ref = it.next();
			if(ref.get().equals(listener)){
				it.remove();
				return true;
			}
		}
		return false;
	}
}
