package de.jutzig.jnotification.event;

public enum NotificationEventType {
	
	MOVED,HIDDEN,DISPLAYED

}
