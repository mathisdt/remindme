/**
 * de.jutzig.jnotification.event.NotificationListener.java
 * created by Johannes Utzig at 06.05.2007
 * 
 * This Source Code is licensed under GPLv3 
 */
package de.jutzig.jnotification.event;

import de.jutzig.jnotification.PopupManager;

/**
 * @author jutzig<p>
 * 
 * Listener Interface for receiving {@link NotificationEvent}s.
 */
public interface NotificationListener {
	
	/**
	 * called after a popup was moved, shown, or hidden from inside the
	 * {@link PopupManager}
	 * @param the event
	 */
	void popupStateChanged(NotificationEvent event);

}
