/**
 * de.jutzig.jnotification.event.NotificationEvent.java
 * created by Johannes Utzig at 06.05.2007
 * 
 * This Source Code is licensed under GPLv3 
 */
package de.jutzig.jnotification.event;

import java.awt.Point;

import de.jutzig.jnotification.JNotificationPopup;

/**
 * @author jutzig<p>
 *
 */
public class NotificationEvent {
	
	private Point from;
	
	private Point to;
	
	private JNotificationPopup popup;
	
	private NotificationEventType type;

	public NotificationEvent(Point from, Point to, JNotificationPopup popup, NotificationEventType type) {
		super();
		this.from = from;
		this.to = to;
		this.popup = popup;
		this.type = type;
	}

	/**
	 * @return the position the popup was moved from
	 */
	public Point getFrom() {
		return from;
	}

	/**
	 * @return the popup that caused the event
	 */
	public JNotificationPopup getPopup() {
		return popup;
	}

	/**
	 * @return the position that the popup was moved to
	 */
	public Point getTo() {
		return to;
	}

	/**
	 * @return the {@link NotificationEventType} of the Event
	 */
	public NotificationEventType getType() {
		return type;
	}
	
	

}