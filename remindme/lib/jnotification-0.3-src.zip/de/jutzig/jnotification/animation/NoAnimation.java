/**
 * de.jutzig.jnotification.animation.NoAnimation.java
 * created by Johannes Utzig at 05.05.2007
 * 
 * This Source Code is licensed under GPLv3 
 */
package de.jutzig.jnotification.animation;

import java.awt.Point;

import de.jutzig.jnotification.JNotificationPopup;

/**
 * @author jutzig<p>
 * 
 * that's the most basic of all {@link Animator}s.<p>
 * 
 * It does nothing then displaying the Popups directly to
 * the given position.
 *
 */
public class NoAnimation implements Animator {

	private JNotificationPopup popup;
	
	/**
	 * passes the {@link JNotificationPopup} to be animated to the Animator.
	 * @param popup
	 */
	public NoAnimation(JNotificationPopup popup) {
		super();
		this.popup = popup;
	}

	/* (non-Javadoc)
	 * @see de.jutzig.jnotification.animation.Animator#hidePopup()
	 */
	public void hidePopup() {
		popup.dispose();

	}

	/* (non-Javadoc)
	 * @see de.jutzig.jnotification.animation.Animator#movePopup(java.awt.Point, java.awt.Point)
	 */
	public void movePopup(Point to) {
		popup.setLocation(to);

	}

	/* (non-Javadoc)
	 * @see de.jutzig.jnotification.animation.Animator#showPopupAt(java.awt.Point)
	 */
	public void showPopupAt(Point p) {
		popup.setLocation(p);
		popup.setVisible(true);

	}

}
