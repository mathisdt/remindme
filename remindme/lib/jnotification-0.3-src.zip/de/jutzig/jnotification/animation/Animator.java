/**
 * de.jutzig.jnotification.animation.Animator.java
 * created by Johannes Utzig at 05.05.2007
 * 
 * This Source Code is licensed under GPLv3 
 */
package de.jutzig.jnotification.animation;

import java.awt.Point;

import de.jutzig.jnotification.JNotificationPopup;
import de.jutzig.jnotification.PopupManager;

/**
 * @author jutzig<p>
 * 
 * an animator does the actual displaying, hiding and moving of {@link JNotificationPopup}s.
 * <p>
 * The animator is called every time the {@link PopupManager} wants a popup to
 * change the state of a popup.
 */
public interface Animator {
	
	/**
	 * called every time the {@link PopupManager} wants to make a popup visible.
	 * The animator is responsible to call {@link JNotificationPopup#setVisible(boolean)}
	 * @param p - to location where the {@link JNotificationPopup} should appear
	 */
	void showPopupAt(Point p);
	
	/**
	 * called every time the {@link PopupManager} wants to make a popup visible.
	 * the animator is responsible for disposing the {@link JNotificationPopup}
	 */
	void hidePopup();
	
	/**
	 * called every time the {@link PopupManager} wants to move a popup. 
	 * @param to - the point where the {@link JNotificationPopup} should be moved to
	 */
	void movePopup(Point to);

}
