package de.jutzig.jnotification.animation;

import java.awt.AWTException;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Robot;
import java.awt.image.BufferedImage;

import de.jutzig.jnotification.JNotificationPopup;
import de.jutzig.jnotification.PopupManager;
import de.jutzig.jnotification.renderer.RenderDelegate;

/**
 * 
 * @author jutzig<p>
 * 
 * A simple Animator that fades {@link JNotificationPopup}s onto the screen.
 * <p>
 * {@link FadeIn} installs itself as a {@link RenderDelegate} of the {@link JNotificationPopup}.
 * When it's asked to display the Popup, it creates a ScreenCapture of the underlaying screen
 * and slowly adjusts the Alpha value for the given animation time.
 * <p>
 * If the {@link PopupManager} wants the animator to move the popup and
 * the animation is still running, it will create a new screen capture.
 * When the animation is over, the Animator removes the {@link RenderDelegate}. 
 *
 */
public class FadeIn implements Animator, RenderDelegate {

	private JNotificationPopup popup;

	private int duration;

	private BufferedImage image;

	private float alpha;

	/**
	 * standard constuctor for {@link FadeIn}.
	 * @param popup - the popup to be animated
	 * @param duration - the time in ms that the fading shall take
	 */
	public FadeIn(JNotificationPopup popup, int duration) {
		super();
		this.popup = popup;
		this.duration = duration;
		popup.setDelegate(this);
	}
	
	/*
	 * (non-Javadoc)
	 * @see de.jutzig.jnotification.animation.Animator#hidePopup()
	 */
	public void hidePopup() {
		popup.dispose();

	}
	
	/*
	 * (non-Javadoc)
	 * @see de.jutzig.jnotification.animation.Animator#movePopup(java.awt.Point)
	 */
	public void movePopup(Point to) {
		popup.setLocation(to);

		if (popup.getRenderDelegate() != null) {
			try {
				image = new Robot().createScreenCapture(popup.getBounds());
			} catch (AWTException e) {
				e.printStackTrace();
			}
		}

	}

	/*
	 * (non-Javadoc)
	 * @see de.jutzig.jnotification.animation.Animator#showPopupAt(java.awt.Point)
	 */
	public void showPopupAt(Point p) {
		popup.setLocation(p);

		Robot robot;
		try {
			robot = new Robot();
			image = robot.createScreenCapture(popup.getBounds());
			popup.setVisible(true);
			animate();

		} catch (AWTException e) {
			e.printStackTrace();
		}

	}

	private void animate() {
		new Thread(new Runnable() {

			public void run() {
				final int steps = duration / 15;
				for (int i = 0; i < steps; i++) {

					final int phase = i;
					alpha = (float) (float) phase / (float) steps;
					popup.repaint();

					try {
						Thread.sleep(15);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

				}
				popup.setDelegate(null);
				popup.repaint();

			}

		}).start();

	}
	
	/*
	 * (non-Javadoc)
	 * @see de.jutzig.jnotification.renderer.RenderDelegate#draw(java.awt.Graphics2D)
	 */
	public void draw(Graphics2D g) {

		g.drawImage(image, 0, 0, popup);
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_ATOP,
				alpha));
		popup.draw(g);
	}

}
