/**
 * de.jutzig.jnotification.renderer.RenderDelegate.java
 * created by Johannes Utzig at 06.05.2007
 * 
 * This Source Code is licensed under GPLv3 
 */
package de.jutzig.jnotification.renderer;

/**
 * @author jutzig
 *  
 */
import java.awt.Graphics;
import java.awt.Graphics2D;

import de.jutzig.jnotification.JNotificationPopup;

/**
 * A <code>RenderDelegate</code> is meant for custom drawing of 
 * a {@link JNotificationPopup}.<p> 
 * As long as the delegate is set, every paint call of the {@link JNotificationPopup}
 * ContentPane is delegated to the RenderDelegate.<p>
 * If you're in need to call the actual paint Method, you can invoke
 * {@link JNotificationPopup#draw(Graphics2D)}
 */
public interface RenderDelegate {
	
	/**
	 * receives the {@link Graphics} object that's passed to the
	 * {@link JNotificationPopup}s ContentPane.
	 * @param g
	 */
	public void draw(Graphics2D g);

}