/**
 * de.jutzig.jnotification.JNotificationPopup.java
 * created by Johannes Utzig at 05.05.2007
 * 
 * This Source Code is licensed under GPLv3 
 */
package de.jutzig.jnotification;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JWindow;

import de.jutzig.jnotification.animation.Animator;
import de.jutzig.jnotification.animation.NoAnimation;
import de.jutzig.jnotification.renderer.RenderDelegate;

/**
 * @author jutzig<p>
 *
 * The {@link JNotificationPopup} extends {@link JWindow} and
 * is used to display the notifications
 * <p>
 * It installs a {@link CustomPane} as its ContentPane to allow
 * delegating the rendering to a {@link RenderDelegate} and therefor it's not
 * recommened to call {@link JNotificationPopup#setContentPane(java.awt.Container)} for client code
 * when you're using custom {@link Animator}s that rely on this feature.
 * 
 */
public class JNotificationPopup extends JWindow {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -526992623659319705L;
	
	private Animator animator;
	
	private Component component;
	
	private RenderDelegate delegate;
	
	/**
	 * The {@link RenderDelegate} that's used to paint the notification
	 * @return delegate
	 */
	public RenderDelegate getRenderDelegate() {
		return delegate;
	}

	/**
	 * Sets the {@link RenderDelegate} that's used to paint the notification.
	 * can be <code>null</code>
	 * @param delegate
	 */
	public void setDelegate(RenderDelegate delegate) {
		this.delegate = delegate;
	}

	/**
	 * creates a new {@link JNotificationPopup} with the given {@link Component} or {@link JComponent}
	 * added to it's ContentPane.
	 * @param component
	 */
	public JNotificationPopup(Component component){
		setContentPane(new CustomPane());
		setAlwaysOnTop(true);
		this.component=component;
		add(component);
		setSize(component.getPreferredSize());

		setAnimator(new NoAnimation(this));
	}

	/**
	 * returns the {@link Animator} that the {@link PopupManager} uses to
	 * change the {@link JNotificationPopup}s state.
	 * @return animator
	 */
	public Animator getAnimator() {
		return animator;
	}

	/**
	 * sets the {@link Animator} that the {@link PopupManager} uses to
	 * change the {@link JNotificationPopup}s state.
	 * @param animator
	 */
	public void setAnimator(Animator animator) {
		this.animator = animator;
	}

	/**
	 * returns the root-component that was added to the {@link JNotificationPopup}s contentPane.
	 * @return component
	 */
	public Component getComponent() {
		return component;
	}

	/**
	 * sets a new root-component to the contentPane.
	 * This causes <ul>
	 * <li>the old component to be removed</li>
	 * <li>the new component to be added</li>
	 * <li>validation of the {@link JNotificationPopup}</li></ul>
	 * @param component
	 */
	public void setComponent(Component component) {
		remove(this.component);
		this.component = component;
		add(component);
		validate();
		
	}
	
	/**
	 * passes the {@link Graphics2D} object to the contentPanes paint method.
	 * This method is used to bypass the {@link RenderDelegate} if there is one.
	 * @param g
	 */
	public void draw(Graphics2D g)
	{
		((CustomPane)getContentPane()).draw(g);
	}
	
	/**
	 * 
	 * @author jutzig
	 * 
	 * A custom pane that is used as the ContentPane of the {@link JNotificationPopup}.
	 * <p>
	 * The pane is installed to allow delegating the paint requests to a {@link RenderDelegate}.
	 * If no {@link RenderDelegate} is set, it behaves exactly as a {@link JPanel}.
	 */
	private class CustomPane extends JPanel
	{
		private static final long serialVersionUID = -2419098280441609009L;

		public CustomPane() {
			setLayout(new BorderLayout(0,0));
			
		}
		@Override
		public void paint(Graphics g) {
			if(delegate!=null)
				delegate.draw((Graphics2D)g);
			else
				super.paint(g);
		}
		
		public void draw(Graphics2D g)
		{
			super.paint(g);
		}
		
	}
}


